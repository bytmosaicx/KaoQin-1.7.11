package com.example.jigong;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
public class AttendanceBootReceiver extends BroadcastReceiver { @Override public void onReceive(Context context, Intent intent) { SharedPreferences p=context.getSharedPreferences(AttendanceReminder.PREF,Context.MODE_PRIVATE); AttendanceReminder.configure(context,p.getBoolean("enabled",false),p.getString("time","20:00"),p.getInt("days",3)); } }
