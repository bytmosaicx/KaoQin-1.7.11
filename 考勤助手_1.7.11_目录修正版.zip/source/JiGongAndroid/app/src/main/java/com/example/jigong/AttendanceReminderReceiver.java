package com.example.jigong;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class AttendanceReminderReceiver extends BroadcastReceiver { @Override public void onReceive(Context context, Intent intent) { AttendanceReminder.notifyNow(context); AttendanceReminder.scheduleNext(context); } }
