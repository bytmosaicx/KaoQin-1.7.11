package com.example.jigong;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.app.Notification;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

final class AttendanceReminder {
    static final String PREF = "attendance_reminder";
    static final String CHANNEL = "attendance_daily_reminder";
    private AttendanceReminder() {}

    static void configure(Context context, boolean enabled, String time, int days) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        days = Math.max(3, Math.min(365, days));
        p.edit().putBoolean("enabled", enabled).putString("time", time == null ? "20:00" : time).putInt("days", days).apply();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context);
        if (am != null) am.cancel(pi);
        if (!enabled) return;
        Calendar c = Calendar.getInstance();
        String[] hm = (time == null ? "20:00" : time).split(":");
        int hour = hm.length > 0 ? parse(hm[0], 20) : 20;
        int minute = hm.length > 1 ? parse(hm[1], 0) : 0;
        c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, days);
        if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
    }
    static void scheduleNext(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        Calendar c = Calendar.getInstance(); String[] hm = p.getString("time", "20:00").split(":");
        c.set(Calendar.HOUR_OF_DAY, hm.length > 0 ? parse(hm[0],20) : 20);
        c.set(Calendar.MINUTE, hm.length > 1 ? parse(hm[1],0) : 0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_YEAR, Math.max(3, p.getInt("days",3)));
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pending(context));
    }
    static PendingIntent pending(Context c) {
        Intent i=new Intent(c, AttendanceReminderReceiver.class);
        return PendingIntent.getBroadcast(c, 7301, i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    }
    static void notifyNow(Context context) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"考勤提醒",NotificationManager.IMPORTANCE_DEFAULT));
        }
        SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        boolean recorded=false;
        try { JSONObject data=new JSONObject(p.getString("snapshot","{}")); recorded=data.optBoolean(today,false); } catch(Exception ignored) {}
        String msg=recorded?"今天已有考勤记录。":"今天还没有考勤记录，请及时记录。";
        Intent launch=context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent content=launch==null?null:PendingIntent.getActivity(context,7302,launch,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("考勤助手提醒").setContentText(msg).setAutoCancel(true);
        if(content!=null)b.setContentIntent(content);
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.notify(7303,b.build());
    }
    private static int parse(String s,int fallback){try{return Integer.parseInt(s);}catch(Exception e){return fallback;}}
}

