package com.example.jigong;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import android.widget.Toast;
import android.widget.EditText;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int CREATE_XLSX_REQUEST = 7314;
    private byte[] pendingXlsx;
    private final ArrayList<Uri> pendingShareUris = new ArrayList<>();
    private int nextShareBatchStart = 0;
    private final ArrayList<String> pendingShareNames = new ArrayList<>();
    private SharedPreferences sharePrefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharePrefs = getSharedPreferences("pending_image_share", MODE_PRIVATE);
        restoreNativeShareTask();
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton("确定", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setNegativeButton("取消", (dialog, which) -> result.cancel())
                    .setPositiveButton("确定", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setText(defaultValue == null ? "" : defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(input)
                    .setNegativeButton("取消", (dialog, which) -> result.cancel())
                    .setPositiveButton("确定", (dialog, which) -> result.confirm(input.getText().toString()))
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
        });
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void launchNextImageShareBatch() {
        launchImageShareBatch(nextShareBatchStart);
    }

    private void launchImageShareBatch(int start) {
        if (pendingShareUris.isEmpty() || start < 0 || start >= pendingShareUris.size()) {
            Toast.makeText(this, "没有待分享的图片", Toast.LENGTH_SHORT).show();
            return;
        }
        int end = Math.min(start + 9, pendingShareUris.size());
        ArrayList<Uri> batch = new ArrayList<>(pendingShareUris.subList(start, end));
        ClipData clip = null;
        for (Uri uri : batch) {
            if (clip == null) clip = ClipData.newUri(getContentResolver(), "考勤图片", uri);
            else clip.addItem(new ClipData.Item(uri));
        }
        nextShareBatchStart = Math.max(nextShareBatchStart, end);
        persistNativeShareTask();
        Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
        send.setType("image/png");
        send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, batch);
        send.setClipData(clip);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "分享考勤图片（第 " + ((start / 9) + 1) + " 批）"));
    }

    private void persistNativeShareTask() {
        if (sharePrefs == null) return;
        JSONArray names = new JSONArray();
        for (String name : pendingShareNames) names.put(name);
        sharePrefs.edit().putString("names", names.toString()).putInt("nextStart", nextShareBatchStart).apply();
    }

    private void restoreNativeShareTask() {
        if (sharePrefs == null) return;
        try {
            JSONArray names = new JSONArray(sharePrefs.getString("names", "[]"));
            File dir = new File(getFilesDir(), "shared");
            for (int i = 0; i < names.length(); i++) {
                String name = names.optString(i, "");
                if (name.isEmpty() || name.contains("..") || name.contains("/")) continue;
                File f = new File(dir, name);
                if (f.isFile()) {
                    pendingShareNames.add(name);
                    pendingShareUris.add(Uri.parse("content://com.example.jigong.share/" + Uri.encode(name)));
                }
            }
            nextShareBatchStart = Math.min(pendingShareUris.size(), Math.max(0, sharePrefs.getInt("nextStart", 0)));
            if (pendingShareUris.isEmpty()) {
                sharePrefs.edit().clear().apply();
            }
        } catch (Exception ignored) {
            pendingShareUris.clear();
            pendingShareNames.clear();
            nextShareBatchStart = 0;
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void shareText(String content, String title) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "考勤报告" : title);
                send.putExtra(Intent.EXTRA_TEXT, content);
                startActivity(Intent.createChooser(send, "导出考勤"));
            });
        }

        @JavascriptInterface
        public void saveXlsx(String json, String filename) {
            try {
                pendingXlsx = buildWorkbook(new JSONObject(json));
                runOnUiThread(() -> {
                    Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    create.addCategory(Intent.CATEGORY_OPENABLE);
                    create.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                    create.putExtra(Intent.EXTRA_TITLE, filename == null ? "考勤表.xlsx" : filename);
                    startActivityForResult(create, CREATE_XLSX_REQUEST);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "生成 Excel 失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void shareImage(String base64, String filename) {
            try {
                byte[] imageBytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getFilesDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建分享目录");
                String safeName = filename == null ? "考勤报表.png" : filename.replaceAll("[^\\p{L}\\p{N}._-]", "_");
                if (!safeName.toLowerCase().endsWith(".png")) safeName += ".png";
                File imageFile = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(imageFile)) { out.write(imageBytes); out.flush(); }
                Uri uri = Uri.parse("content://com.example.jigong.share/" + Uri.encode(safeName));
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newUri(getContentResolver(), "考勤报表", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "分享考勤报表"));
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "分享报表图片失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void shareImages(String imagesJson) {
            try {
                JSONArray images = new JSONArray(imagesJson);
                if (images.length() == 0) throw new IllegalArgumentException("没有可分享的图片");
                File dir = new File(getFilesDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建分享目录");
                pendingShareUris.clear();
                pendingShareNames.clear();
                nextShareBatchStart = 0;
                for (int i = 0; i < images.length(); i++) {
                    JSONObject item = images.getJSONObject(i);
                    String name = item.optString("name", "考勤记录_" + (i + 1) + ".png").replaceAll("[^\\p{L}\\p{N}._-]", "_");
                    if (!name.toLowerCase().endsWith(".png")) name += ".png";
                    byte[] bytes = Base64.decode(item.getString("data"), Base64.DEFAULT);
                    File file = new File(dir, name);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); out.flush(); }
                    pendingShareUris.add(Uri.parse("content://com.example.jigong.share/" + Uri.encode(name)));
                    pendingShareNames.add(name);
                }
                nextShareBatchStart = 0;
                runOnUiThread(() -> launchNextImageShareBatch());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "准备分享图片失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void shareNextImageBatch() {
            runOnUiThread(() -> launchNextImageShareBatch());
        }

        @JavascriptInterface
        public void sharePreviousImageBatch() {
            runOnUiThread(() -> launchImageShareBatch(Math.max(0, nextShareBatchStart - 9)));
        }

        @JavascriptInterface
        public String getPendingImageShareState() {
            JSONObject state = new JSONObject();
            try {
                state.put("count", pendingShareUris.size());
                state.put("nextStart", nextShareBatchStart);
            } catch (Exception ignored) { }
            return state.toString();
        }

        public void clearPendingImageShare() {
            File dir = new File(getFilesDir(), "shared");
            for (String name : pendingShareNames) new File(dir, name).delete();
            pendingShareUris.clear();
            pendingShareNames.clear();
            nextShareBatchStart = 0;
            persistNativeShareTask();
        }

        @JavascriptInterface
        public void shareCsv(String csv) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/csv");
                send.putExtra(Intent.EXTRA_SUBJECT, "记工记录");
                send.putExtra(Intent.EXTRA_TEXT, csv);
                startActivity(Intent.createChooser(send, "导出记工记录"));
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_XLSX_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null || pendingXlsx == null) {
            pendingXlsx = null;
            return;
        }
        Uri uri = data.getData();
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("无法写入所选文件");
            out.write(pendingXlsx);
            out.flush();
            pendingXlsx = null;
            Toast.makeText(this, "Excel 表格已保存", Toast.LENGTH_SHORT).show();
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(uri, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivity(Intent.createChooser(open, "打开考勤表"));
            } catch (Exception ignored) {
                Toast.makeText(this, "文件已保存，可在 WPS 或 Excel 中打开", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            pendingXlsx = null;
            Toast.makeText(this, "保存 Excel 失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private byte[] buildWorkbook(JSONObject payload) throws Exception {
        JSONArray rows = payload.optJSONArray("rows");
        if (rows == null) throw new IllegalArgumentException("表格内容为空");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes, StandardCharsets.UTF_8)) {
            put(zip, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                    "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                    "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                    "</Types>");
            put(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            put(zip, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"考勤表\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            put(zip, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            put(zip, "xl/styles.xml", stylesXml());
            put(zip, "xl/worksheets/sheet1.xml", sheetXml(rows));
        }
        return bytes.toByteArray();
    }

    private String sheetXml(JSONArray rows) throws Exception {
        int maxColumns = 1;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row != null && row.optJSONArray("cells") != null) maxColumns = Math.max(maxColumns, row.optJSONArray("cells").length());
        }
        StringBuilder x = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>");
        x.append("<col min=\"1\" max=\"1\" width=\"20\" customWidth=\"1\"/>");
        if (maxColumns >= 5) x.append("<col min=\"2\" max=\"4\" width=\"16\" customWidth=\"1\"/><col min=\"5\" max=\"5\" width=\"").append(maxColumns >= 6 ? "18" : "30").append("\" customWidth=\"1\"/>");
        if (maxColumns >= 6) x.append("<col min=\"6\" max=\"6\" width=\"24\" customWidth=\"1\"/>");
        x.append("</cols><sheetData>");
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            JSONArray cells = row.optJSONArray("cells");
            if (cells == null) continue;
            String style = row.optString("style", "normal");
            int styleId = "title".equals(style) ? 1 : "header".equals(style) ? 2 : "section".equals(style) ? 3 : "total".equals(style) ? 4 : 0;
            x.append("<row r=\"").append(i + 1).append("\">");
            for (int j = 0; j < cells.length(); j++) {
                String ref = columnName(j + 1) + (i + 1);
                String value = cells.optString(j, "");
                x.append("<c r=\"").append(ref).append("\" t=\"inlineStr\" s=\"").append(styleId).append("\"><is><t xml:space=\"preserve\">").append(xml(value)).append("</t></is></c>");
            }
            x.append("</row>");
        }
        x.append("</sheetData></worksheet>");
        return x.toString();
    }

    private String stylesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"3\"><font><sz val=\"11\"/><name val=\"等线\"/></font><font><b/><sz val=\"16\"/><color rgb=\"FF176B54\"/><name val=\"等线\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"等线\"/></font></fonts>" +
                "<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE5F2EB\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF176B54\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
                "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style=\"thin\"><color rgb=\"FFE2EAE5\"/></left><right style=\"thin\"><color rgb=\"FFE2EAE5\"/></right><top style=\"thin\"><color rgb=\"FFE2EAE5\"/></top><bottom style=\"thin\"><color rgb=\"FFE2EAE5\"/></bottom><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"5\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"/>" +
                "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private void put(ZipOutputStream zip, String name, String content) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }
    private String columnName(int n) {
        StringBuilder s = new StringBuilder();
        while (n > 0) { int r = (n - 1) % 26; s.insert(0, (char) ('A' + r)); n = (n - 1) / 26; }
        return s.toString();
    }
    private String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
